import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ImprimerBonRetourPage } from './imprimer-bon-retour';

@NgModule({
  declarations: [
    ImprimerBonRetourPage,
  ],
  imports: [
    IonicPageModule.forChild(ImprimerBonRetourPage),
  ],
})
export class ImprimerBonRetourPageModule {}
