import { Component, ViewChild } from '@angular/core';
import { IonicPage, NavController, NavParams, Nav, AlertController } from 'ionic-angular';
import { BonSortiePage } from '../bon-sortie/bon-sortie';
import { BonRetourPage } from '../bon-retour/bon-retour';
import { EmployeurPage } from '../employeur/employeur';
import { PointagePage } from '../pointage/pointage';
import { SalairePage } from '../salaire/salaire';
import { DemandeCongePage } from '../demande-conge/demande-conge';
import { DevisPage } from '../devis/devis';
import { ListeFacturePage } from '../liste-facture/liste-facture';
import { FacturePage } from '../facture/facture';
import { StockPage } from '../stock/stock';
import { TabsPage } from '../tabs/tabs';
import { ProduitPage } from '../produit/produit';
import { ParamPage } from '../param/param';
import { SocietePage } from '../societe/societe';
import { RessourcesPage } from '../ressources/ressources';
import { SocieteProvider } from '../../providers/societe/societe';
import { HomePage } from '../home/home';
import { TestPage } from '../test/test';
import { AbscencePage } from '../abscence/abscence';

/**
 * Generated class for the TempPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-temp',
  templateUrl: 'temp.html',
})
export class TempPage {
  @ViewChild(Nav) nav:Nav;
  listsociete
  soc
  constructor(public navCtrl: NavController,    private alertCtrl : AlertController,
     public navParams: NavParams,public providerSociete : SocieteProvider) {
    this.getsociete()
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad TempPage');
  }
  getsociete(){
    this.providerSociete.loadsociete()
    .then(data => {
      this.listsociete = data;
      console.log("listsociete:::::",this.listsociete);
     this.soc = this.listsociete[0]
    });
  }
///////////////menu
gotoSortie(){
  this.navCtrl.setRoot(BonSortiePage)
  
}
gotoretour(){
  this.navCtrl.setRoot(BonRetourPage)
  
}
gotoempl(){
  this.navCtrl.setRoot(EmployeurPage)
}
gotopointage(){
  this.navCtrl.setRoot(PointagePage)
}
gotosalaire(){
  this.navCtrl.setRoot(SalairePage)
}
gotodemande(){
  this.navCtrl.setRoot(DemandeCongePage)
}
gotoDevis(){
  this.navCtrl.setRoot(DevisPage)
}
gotolistfact(){
  this.navCtrl.setRoot(ListeFacturePage)
}
gotofacture(){
  this.navCtrl.setRoot(FacturePage)
}
gotostock(){
  this.navCtrl.setRoot(StockPage)
}
gotomvt(){
  this.navCtrl.setRoot(TabsPage)
}
gotoproduit(){
  this.navCtrl.setRoot(ProduitPage)
}
gotoparam(){
  this.navCtrl.setRoot(ParamPage)
}
gotosociete(){
  this.navCtrl.setRoot(SocietePage)
}
gotoressource(){
  this.navCtrl.setRoot(RessourcesPage)
}
gototemp(){
  this.navCtrl.setRoot(TempPage)
}
gotoLogOut(){
  let alert = this.alertCtrl.create({
    title: 'are you sure about leaving the app?',
    message: 'please confirm',
    buttons: [
      {
        text: 'Cancel',
        role: 'cancel',
        handler: () => {
          console.log('Cancel clicked');
        }
      },
      {
        text: 'yes',
        handler: () => {
          window.localStorage.setItem("username", "  ");
          window.localStorage.setItem("password", "  ");
          this.navCtrl.setRoot(HomePage);
        }
      }
    ]
  });
  alert.present();
}
gotouser(){
  this.navCtrl.setRoot(TestPage)
}
gotoabscence(){
  this.navCtrl.setRoot(AbscencePage)
}

}

